#!/bin/sh
set -eu
echo "========================================="
echo "  Ledger Agent 企业级作品集全链路验收"
echo "========================================="

echo "[1/3] 运行单元测试..."
go test ./...

echo "[2/3] 运行高并发竞态检测 (-race)..."
go test -race ./...

echo "[3/3] 运行离线安全评测门禁 (Eval)..."
go run ./cmd/server eval

echo ""
echo ">>> 全部验收通过！恭喜完成 Go + AI 企业级工程作品集！<<<"
